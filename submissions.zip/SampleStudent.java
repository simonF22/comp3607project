package comp3607project;

public class SampleStudent {
    @SuppressWarnings("unused")
    private int sampleAttribute; // Correct naming convention for attribute
    
    public void sampleMethod() {
        // Sample method for testing purposes
    }
}

